#!/bin/sh
phpunit Test_Not_Gettexted test_not-gettexted.php
